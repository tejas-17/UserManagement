package com.assignment.userManagement.Model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "user") // Explicitly specifying the table name
@Data // Lombok will generate getters, setters, toString, equals, and hashCode methods

public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;

    @Column(name = "email_id")
    private String emailId;

    private int age;

    @Version // Optimistic locking version field
    private Integer version;

    // Getters and Setters
}
