package com.assignment.userManagement.Service;

import com.assignment.userManagement.Model.User;
import com.assignment.userManagement.Repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class userService {

    @Autowired
    private UserRepository userRepo;

    @Transactional
    public User createUserfromData(User user) {
        return userRepo.save(user); // Persist the new user into the database
    }

    public Optional<User> findUserByIdfromData(Long id) {
        return userRepo.findById(id); // Retrieve user by ID
    }

    @Transactional
    public User updateUserByIdfromData(User user) {
        try {
            // First, check if the user exists
            Optional<User> existingUserOptional = userRepo.findById(user.getId());
            if (existingUserOptional.isPresent()) {
                User existingUser = existingUserOptional.get();

                // Update only the fields that need changes
                existingUser.setUsername(user.getUsername());
                existingUser.setEmailId(user.getEmailId());
                existingUser.setAge(user.getAge());

                // Save the updated user (OptimisticLocking will be triggered here if there's a version mismatch)
                return userRepo.save(existingUser);
            } else {
                throw new RuntimeException("User not found with id: " + user.getId());
            }
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new RuntimeException("Concurrent update detected. Please retry.", e);
        }
    }

    @Transactional
    public String deleteByIdFromData(Long id) {
        if (userRepo.existsById(id)) {
            userRepo.deleteById(id); // Delete user by ID
            return "Deleted user with id: " + id;
        } else {
            return "User with id: " + id + " does not exist.";
        }
    }
}
