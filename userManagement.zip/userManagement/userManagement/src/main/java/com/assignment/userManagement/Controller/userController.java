package com.assignment.userManagement.Controller;


import com.assignment.userManagement.Model.User;
import com.assignment.userManagement.Service.userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/v1")
public class userController {

@Autowired
userService userservice;
    @PostMapping("/users")
    public ResponseEntity<?> createUser(@RequestBody User user) {
        // No need to check for existing user by ID, since ID is auto-generated
        try {
            // Create the user and return HTTP 201 Created status
            User createdUser = userservice.createUserfromData(user);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(createdUser);
        } catch (Exception e) {
            // Handle any possible exceptions and return a 400 Bad Request or other appropriate status
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Failed to create user: " + e.getMessage());
        }
    }




    @GetMapping("/users/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        Optional<User> user = userservice.findUserByIdfromData(id);

        // If the user is found, return the user with HTTP 200 status
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        }

        // If the user is not found, return 404 Not Found
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(null); // Or return a custom error message if desired
    }


    @PutMapping("/users/{id}")
    public ResponseEntity<User> updateUserById(@RequestBody User user, @PathVariable Long id) {
        Optional<User> existingUser = userservice.findUserByIdfromData(id);

        // If the user is found, update the user
        if (existingUser.isPresent()) {
            User updatedUser = userservice.updateUserByIdfromData(user);
            return ResponseEntity.ok(updatedUser); // Return HTTP 200 with updated user
        }

        // If the user is not found, return 404 Not Found
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(null); // Or a custom message or body if you prefer
    }


    @DeleteMapping("/users/{id}")
    public ResponseEntity<String> deleteById(@PathVariable Long id){

        Optional<User> existingUser=userservice.findUserByIdfromData(id);

        if(existingUser.isPresent()){
            String userDeleted=userservice.deleteByIdFromData(id);
            return ResponseEntity.ok(userDeleted);
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
    }






}
